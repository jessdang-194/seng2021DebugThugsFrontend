import SignupPage from "@/signup-page"

export default function Page() {
  return <SignupPage />
}

