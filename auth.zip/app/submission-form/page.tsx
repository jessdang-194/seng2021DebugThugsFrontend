import SubmissionForm from "@/submission-form"

export default function Page() {
  return <SubmissionForm />
}

