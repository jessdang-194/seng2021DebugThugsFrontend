import SubmissionConfirmation from "@/components/submission-confirmation"

export default function MainSubmissionConfirmationPage() {
  return <SubmissionConfirmation />
}

