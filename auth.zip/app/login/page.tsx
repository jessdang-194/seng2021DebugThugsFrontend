import LoginPage from "@/login-page"

export default function Page() {
  return <LoginPage />
}

